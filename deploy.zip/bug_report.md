﻿---
name: Bug Report
about: Reportar um comportamento inesperado
title: '[BUG] '
labels: bug
---

**Descrição do Bug**

**Passos para Reproduzir**
1. 
2. 

**Comportamento Esperado**

**Comportamento Atual**

**Screenshots (se aplicável)**

**Ambiente:**
- OS: [ex: Windows 11]
- Navegador [ex: Chrome 120]
